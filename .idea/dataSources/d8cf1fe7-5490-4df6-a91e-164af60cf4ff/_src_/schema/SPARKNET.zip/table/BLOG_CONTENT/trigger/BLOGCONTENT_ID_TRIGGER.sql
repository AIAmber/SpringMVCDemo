CREATE TRIGGER BLOGCONTENT_ID_TRIGGER
BEFORE INSERT
  ON BLOG_CONTENT
FOR EACH ROW WHEN (FOR EACH ROW )
begin
	select bloguser_id_seq.nextval into :new.ID from sys.dual;
end;
/
