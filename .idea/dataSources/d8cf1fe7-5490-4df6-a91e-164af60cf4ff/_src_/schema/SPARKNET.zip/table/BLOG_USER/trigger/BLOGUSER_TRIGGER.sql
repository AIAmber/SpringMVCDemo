CREATE TRIGGER BLOGUSER_TRIGGER
BEFORE INSERT
  ON BLOG_USER
FOR EACH ROW WHEN (FOR EACH ROW )
begin
	select bloguser_id_seq.nextval into :new.ID from sys.dual;
end;
/
